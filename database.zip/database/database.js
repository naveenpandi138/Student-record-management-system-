const path = require("path");
const fs = require("fs");
const Database = require("better-sqlite3");

const DB_PATH = path.join(__dirname, "students.db");
const SCHEMA_PATH = path.join(__dirname, "schema.sql");

// Creates the DB file automatically if it doesn't exist
const db = new Database(DB_PATH);

// Initialize schema on startup
const schema = fs.readFileSync(SCHEMA_PATH, "utf8");
db.exec(schema);

module.exports = db;
