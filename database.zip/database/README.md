# Database — Student Record Management System

This folder contains the database layer only.

- `schema.sql` — table definition for the `students` table, plus sample seed data
- `database.js` — Node.js connection helper (uses `better-sqlite3`) that opens/creates
  `students.db` and runs `schema.sql` automatically on startup

## Using it standalone

If you just want the raw SQL to set up the database yourself (e.g. in a
different DB tool, or to adapt it to MySQL/PostgreSQL), open `schema.sql` and
run it directly.

If you want to use it with Node.js (as the backend does), place both files
inside a `db/` folder next to your backend code, install `better-sqlite3`:

```bash
npm install better-sqlite3
```

then `require("./db/database")` from your server file. It will create
`students.db` automatically the first time it runs.

## Schema

```sql
CREATE TABLE students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    roll_number TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    phone TEXT,
    course TEXT NOT NULL,
    year INTEGER NOT NULL,
    address TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```
