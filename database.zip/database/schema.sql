-- Student Record Management System - Database Schema

CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    roll_number TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    phone TEXT,
    course TEXT NOT NULL,
    year INTEGER NOT NULL,
    address TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Sample seed data
INSERT OR IGNORE INTO students (roll_number, name, email, phone, course, year, address)
VALUES
    ('CS2023001', 'Aarav Sharma', 'aarav.sharma@example.com', '9876543210', 'B.Tech Computer Science', 2, 'Delhi, India'),
    ('CS2023002', 'Priya Verma', 'priya.verma@example.com', '9876543211', 'B.Tech Computer Science', 2, 'Mumbai, India'),
    ('EC2023010', 'Rohan Gupta', 'rohan.gupta@example.com', '9876543212', 'B.Tech Electronics', 1, 'Bangalore, India');
