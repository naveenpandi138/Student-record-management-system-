# Student Record Management System

A full-stack college project for managing student records — add, view, search, edit, and delete students.

## Tech Stack

- **Frontend:** HTML, CSS, JavaScript (vanilla, no build step required)
- **Backend:** Node.js + Express (REST API)
- **Database:** SQLite (via `better-sqlite3`) — a single file database, no server setup needed

## Project Structure

```
student-record-management-system/
├── backend/
│   ├── controllers/
│   │   └── studentController.js   # CRUD logic
│   ├── routes/
│   │   └── students.js            # API routes
│   ├── db/
│   │   ├── database.js            # DB connection + auto schema init
│   │   └── schema.sql             # Table definition + sample data
│   ├── server.js                  # Express app entry point
│   ├── package.json
│   └── .env.example
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── script.js
└── README.md
```

## Getting Started

### 1. Install backend dependencies

```bash
cd backend
npm install
```

### 2. Run the server

```bash
npm start
```

The server starts at `http://localhost:5000` and automatically creates the SQLite
database file (`backend/db/students.db`) with the schema and sample data the
first time it runs.

### 3. Open the frontend

The backend also serves the frontend as static files, so once the server is
running, just open:

```
http://localhost:5000
```

in your browser. (Alternatively, open `frontend/index.html` directly in a
browser — the API calls will still work as long as the backend is running on
port 5000.)

## API Endpoints

| Method | Endpoint              | Description              |
|--------|------------------------|--------------------------|
| GET    | `/api/students`        | Get all students (supports `?search=` query) |
| GET    | `/api/students/:id`    | Get a single student     |
| POST   | `/api/students`        | Create a new student     |
| PUT    | `/api/students/:id`    | Update a student         |
| DELETE | `/api/students/:id`    | Delete a student         |
| GET    | `/api/health`          | Health check             |

### Sample request body (POST/PUT)

```json
{
  "roll_number": "CS2023003",
  "name": "Neha Singh",
  "email": "neha.singh@example.com",
  "phone": "9876543213",
  "course": "B.Tech Computer Science",
  "year": 3,
  "address": "Pune, India"
}
```

## Features

- Add new student records
- View all students in a table
- Search students by name, roll number, or course
- Edit existing student records
- Delete student records
- Input validation and duplicate (roll number / email) handling
- Sample seed data included for quick demo

## Notes for Uploading to GitHub

- The `.gitignore` file excludes `node_modules/` and the generated
  `students.db` file, so your repo stays clean. Anyone who clones the repo
  just needs to run `npm install` inside `backend/` and the database will be
  regenerated automatically from `schema.sql`.
- If your instructor wants a MySQL/PostgreSQL version instead of SQLite, the
  schema in `backend/db/schema.sql` can be adapted with minimal changes since
  it uses standard SQL types.

## Possible Extensions (for extra credit)

- Add authentication (admin login)
- Add pagination for large record sets
- Export records to CSV/PDF
- Add attendance or grades modules linked to each student
