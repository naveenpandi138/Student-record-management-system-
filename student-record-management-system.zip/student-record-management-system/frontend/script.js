const API_URL = "http://localhost:5000/api/students";

const form = document.getElementById("student-form");
const formTitle = document.getElementById("form-title");
const submitBtn = document.getElementById("submit-btn");
const cancelBtn = document.getElementById("cancel-btn");
const tableBody = document.getElementById("student-table-body");
const emptyMessage = document.getElementById("empty-message");
const searchInput = document.getElementById("search-input");

const fields = ["student-id", "roll_number", "name", "email", "phone", "course", "year", "address"];

// ---- Fetch & render students ----
async function fetchStudents(query = "") {
  try {
    const url = query ? `${API_URL}?search=${encodeURIComponent(query)}` : API_URL;
    const res = await fetch(url);
    const data = await res.json();
    renderTable(data);
  } catch (err) {
    console.error("Failed to fetch students:", err);
    alert("Could not connect to the backend server. Make sure it is running on port 5000.");
  }
}

function renderTable(students) {
  tableBody.innerHTML = "";

  if (!students.length) {
    emptyMessage.classList.remove("hidden");
    return;
  }
  emptyMessage.classList.add("hidden");

  students.forEach((s) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${escapeHtml(s.roll_number)}</td>
      <td>${escapeHtml(s.name)}</td>
      <td>${escapeHtml(s.email)}</td>
      <td>${escapeHtml(s.phone || "-")}</td>
      <td>${escapeHtml(s.course)}</td>
      <td>${s.year}</td>
      <td>
        <button class="action-btn edit-btn" data-id="${s.id}">Edit</button>
        <button class="action-btn delete-btn" data-id="${s.id}">Delete</button>
      </td>
    `;
    tableBody.appendChild(tr);
  });
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

// ---- Form submit (create or update) ----
form.addEventListener("submit", async (e) => {
  e.preventDefault();

  const id = document.getElementById("student-id").value;
  const payload = {
    roll_number: document.getElementById("roll_number").value.trim(),
    name: document.getElementById("name").value.trim(),
    email: document.getElementById("email").value.trim(),
    phone: document.getElementById("phone").value.trim(),
    course: document.getElementById("course").value.trim(),
    year: Number(document.getElementById("year").value),
    address: document.getElementById("address").value.trim(),
  };

  try {
    let res;
    if (id) {
      res = await fetch(`${API_URL}/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
    } else {
      res = await fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
    }

    const data = await res.json();
    if (!res.ok) {
      alert(data.error || "Something went wrong");
      return;
    }

    resetForm();
    fetchStudents(searchInput.value);
  } catch (err) {
    console.error(err);
    alert("Could not connect to the backend server.");
  }
});

// ---- Edit / Delete via event delegation ----
tableBody.addEventListener("click", async (e) => {
  const id = e.target.dataset.id;
  if (!id) return;

  if (e.target.classList.contains("delete-btn")) {
    if (!confirm("Delete this student record?")) return;
    await fetch(`${API_URL}/${id}`, { method: "DELETE" });
    fetchStudents(searchInput.value);
  }

  if (e.target.classList.contains("edit-btn")) {
    const res = await fetch(`${API_URL}/${id}`);
    const s = await res.json();

    document.getElementById("student-id").value = s.id;
    document.getElementById("roll_number").value = s.roll_number;
    document.getElementById("name").value = s.name;
    document.getElementById("email").value = s.email;
    document.getElementById("phone").value = s.phone || "";
    document.getElementById("course").value = s.course;
    document.getElementById("year").value = s.year;
    document.getElementById("address").value = s.address || "";

    formTitle.textContent = "Edit Student";
    submitBtn.textContent = "Update Student";
    cancelBtn.classList.remove("hidden");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
});

cancelBtn.addEventListener("click", resetForm);

function resetForm() {
  form.reset();
  document.getElementById("student-id").value = "";
  formTitle.textContent = "Add New Student";
  submitBtn.textContent = "Add Student";
  cancelBtn.classList.add("hidden");
}

// ---- Search ----
let searchTimeout;
searchInput.addEventListener("input", () => {
  clearTimeout(searchTimeout);
  searchTimeout = setTimeout(() => fetchStudents(searchInput.value), 300);
});

// ---- Init ----
fetchStudents();
