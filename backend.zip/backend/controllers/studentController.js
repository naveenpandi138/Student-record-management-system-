const db = require("../db/database");

// GET all students (supports optional ?search= query on name/roll/course)
function getAllStudents(req, res) {
  const { search } = req.query;
  let rows;

  if (search) {
    const term = `%${search}%`;
    rows = db
      .prepare(
        `SELECT * FROM students
         WHERE name LIKE ? OR roll_number LIKE ? OR course LIKE ?
         ORDER BY id DESC`
      )
      .all(term, term, term);
  } else {
    rows = db.prepare("SELECT * FROM students ORDER BY id DESC").all();
  }

  res.json(rows);
}

// GET single student by id
function getStudentById(req, res) {
  const { id } = req.params;
  const row = db.prepare("SELECT * FROM students WHERE id = ?").get(id);

  if (!row) {
    return res.status(404).json({ error: "Student not found" });
  }
  res.json(row);
}

// POST create a new student
function createStudent(req, res) {
  const { roll_number, name, email, phone, course, year, address } = req.body;

  if (!roll_number || !name || !email || !course || !year) {
    return res.status(400).json({
      error: "roll_number, name, email, course and year are required",
    });
  }

  try {
    const stmt = db.prepare(`
      INSERT INTO students (roll_number, name, email, phone, course, year, address)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    const info = stmt.run(roll_number, name, email, phone || null, course, year, address || null);
    const newStudent = db.prepare("SELECT * FROM students WHERE id = ?").get(info.lastInsertRowid);
    res.status(201).json(newStudent);
  } catch (err) {
    if (err.message.includes("UNIQUE")) {
      return res.status(409).json({ error: "Roll number or email already exists" });
    }
    res.status(500).json({ error: err.message });
  }
}

// PUT update an existing student
function updateStudent(req, res) {
  const { id } = req.params;
  const existing = db.prepare("SELECT * FROM students WHERE id = ?").get(id);

  if (!existing) {
    return res.status(404).json({ error: "Student not found" });
  }

  const {
    roll_number = existing.roll_number,
    name = existing.name,
    email = existing.email,
    phone = existing.phone,
    course = existing.course,
    year = existing.year,
    address = existing.address,
  } = req.body;

  try {
    db.prepare(`
      UPDATE students
      SET roll_number = ?, name = ?, email = ?, phone = ?, course = ?, year = ?, address = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(roll_number, name, email, phone, course, year, address, id);

    const updated = db.prepare("SELECT * FROM students WHERE id = ?").get(id);
    res.json(updated);
  } catch (err) {
    if (err.message.includes("UNIQUE")) {
      return res.status(409).json({ error: "Roll number or email already exists" });
    }
    res.status(500).json({ error: err.message });
  }
}

// DELETE a student
function deleteStudent(req, res) {
  const { id } = req.params;
  const existing = db.prepare("SELECT * FROM students WHERE id = ?").get(id);

  if (!existing) {
    return res.status(404).json({ error: "Student not found" });
  }

  db.prepare("DELETE FROM students WHERE id = ?").run(id);
  res.json({ message: "Student deleted successfully" });
}

module.exports = {
  getAllStudents,
  getStudentById,
  createStudent,
  updateStudent,
  deleteStudent,
};
