# Backend — Student Record Management System

Node.js + Express REST API for managing student records. This package expects
the database files (`schema.sql` and `database.js`) to be placed in a `db/`
subfolder — see the separate database zip.

## Structure

```
backend/
├── controllers/
│   └── studentController.js   # CRUD logic
├── routes/
│   └── students.js            # API routes
├── db/                        # <-- add files from the database zip here
│   ├── database.js
│   └── schema.sql
├── server.js                  # Express app entry point
├── package.json
└── .env.example
```

## Setup

1. Add the `db/` folder (from the database zip) into this `backend/` folder.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the server:
   ```bash
   npm start
   ```

Server runs at `http://localhost:5000`.

## API Endpoints

| Method | Endpoint              | Description              |
|--------|------------------------|--------------------------|
| GET    | `/api/students`        | Get all students (supports `?search=`) |
| GET    | `/api/students/:id`    | Get a single student     |
| POST   | `/api/students`        | Create a new student     |
| PUT    | `/api/students/:id`    | Update a student         |
| DELETE | `/api/students/:id`    | Delete a student         |
| GET    | `/api/health`          | Health check             |
