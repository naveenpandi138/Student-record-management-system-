const express = require("express");
const cors = require("cors");
const path = require("path");
const studentRoutes = require("./routes/students");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// Serve the frontend as static files (optional convenience for grading/demo)
app.use(express.static(path.join(__dirname, "..", "frontend")));

// API routes
app.use("/api/students", studentRoutes);

// Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", message: "Student Record Management API is running" });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
  console.log(`Frontend available at http://localhost:${PORT}`);
});
